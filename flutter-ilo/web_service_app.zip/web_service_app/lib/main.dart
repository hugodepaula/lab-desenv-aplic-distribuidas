import 'package:flutter/material.dart';
import 'package:web_service_app/home.dart';

void main() {
  runApp(MaterialApp(
    home: home(),
  ));
}
